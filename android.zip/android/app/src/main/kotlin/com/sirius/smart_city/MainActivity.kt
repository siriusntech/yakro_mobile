package com.sirius.smart_city

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
